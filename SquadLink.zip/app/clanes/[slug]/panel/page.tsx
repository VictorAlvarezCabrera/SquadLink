import Link from "next/link";
import { notFound, redirect } from "next/navigation";

import { requireViewer } from "@/lib/auth/session";
import { getClanBySlug, getClanMembers, getClanRequests } from "@/services/squadlink-service";

import { MetricCard } from "@/components/shared/metric-card";
import { Button } from "@/components/ui/button";

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const viewer = await requireViewer();
  const { slug } = await params;
  const clan = await getClanBySlug(slug);

  if (!clan) {
    notFound();
  }

  if (viewer.profile.role !== "admin" && viewer.profile.id !== clan.leaderProfileId) {
    redirect(`/clanes/${clan.slug}`);
  }

  const [members, requests] = await Promise.all([getClanMembers(clan.id), getClanRequests(clan.id)]);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm uppercase tracking-[0.3em] text-amber-300">Panel de clan</p>
          <h1 className="mt-2 text-4xl font-semibold text-white">{clan.name}</h1>
        </div>
        <Link href={`/clanes/${clan.slug}/solicitudes`}>
          <Button className="bg-amber-400 text-slate-950 hover:bg-amber-300">Revisar solicitudes</Button>
        </Link>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <MetricCard label="Miembros" value={String(members.length)} hint="Incluye liderazgo y miembros activos." />
        <MetricCard label="Solicitudes" value={String(requests.length)} hint="Pendientes de revisión." />
        <MetricCard label="Visibilidad" value={clan.visibility} hint="Control público o privado." />
      </div>
    </div>
  );
}
