import type { ReactNode } from "react";

import { requireViewer } from "@/lib/auth/session";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default async function Page() {
  await requireViewer();

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <div>
        <p className="text-sm uppercase tracking-[0.3em] text-amber-300">Nuevo clan</p>
        <h1 className="mt-2 text-4xl font-semibold text-white">Crear clan</h1>
      </div>
      <Card className="border-white/10 bg-white/5 text-white">
        <CardHeader>
          <CardTitle>Formulario base del clan</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-5">
          <Field label="Nombre"><Input className="border-white/10 bg-slate-950/60" placeholder="Nightwatch Protocol" /></Field>
          <Field label="Tagline"><Input className="border-white/10 bg-slate-950/60" placeholder="Qué os hace distintos" /></Field>
          <Field label="Descripción"><Textarea className="min-h-32 border-white/10 bg-slate-950/60" placeholder="Objetivo, tono y ritmo del clan" /></Field>
          <Button className="w-full bg-amber-400 text-slate-950 hover:bg-amber-300">Guardar estructura</Button>
        </CardContent>
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-2">
      <Label className="text-slate-200">{label}</Label>
      {children}
    </div>
  );
}
