import { formatDateTime } from "@/lib/format";
import { listLfgPosts } from "@/services/squadlink-service";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function Page() {
  const posts = await listLfgPosts();

  return (
    <div className="space-y-8">
      <div>
        <p className="text-sm uppercase tracking-[0.3em] text-amber-300">Looking For Group</p>
        <h1 className="mt-2 text-4xl font-semibold text-white">LFG</h1>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        {posts.map((post) => (
          <Card key={post.id} className="border-white/10 bg-white/5 text-white">
            <CardHeader>
              <div className="flex items-center justify-between gap-3">
                <CardTitle>{post.title}</CardTitle>
                <Badge className="bg-emerald-400/15 text-emerald-100">{post.status}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm leading-6 text-slate-300">{post.description}</p>
              <div className="flex flex-wrap gap-2">
                {post.platforms.map((platform) => (
                  <Badge key={platform} variant="outline" className="border-white/10 text-slate-100">
                    {platform}
                  </Badge>
                ))}
              </div>
              <p className="text-sm text-slate-400">Caduca: {formatDateTime(post.expiresAt)}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
