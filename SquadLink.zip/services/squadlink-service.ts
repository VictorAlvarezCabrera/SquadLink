import {
  clanJoinRequests,
  clanMembers,
  clans,
  eventAttendees,
  events,
  games,
  lfgPosts,
  platforms,
  profiles,
  reports,
  reviews,
} from "@/data/demo";
import { calculateCompatibility } from "@/lib/compatibility";

export async function getCatalog() {
  return { games, platforms };
}

export async function listFeaturedClans() {
  return clans.slice(0, 3);
}

export async function listClans() {
  return clans;
}

export async function getClanBySlug(slug: string) {
  return clans.find((clan) => clan.slug === slug) ?? null;
}

export async function getClanMembers(clanId: string) {
  return clanMembers
    .filter((member) => member.clanId === clanId)
    .map((member) => ({
      ...member,
      profile: profiles.find((profile) => profile.id === member.profileId)!,
    }));
}

export async function getClanRequests(clanId: string) {
  return clanJoinRequests
    .filter((request) => request.clanId === clanId)
    .map((request) => ({
      ...request,
      profile: profiles.find((profile) => profile.id === request.profileId)!,
    }));
}

export async function listEvents() {
  return events.map((event) => ({
    ...event,
    clan: clans.find((clan) => clan.id === event.clanId)!,
    game: games.find((game) => game.id === event.gameId)!,
  }));
}

export async function getEventById(id: string) {
  const event = events.find((entry) => entry.id === id);
  if (!event) {
    return null;
  }

  return {
    ...event,
    clan: clans.find((clan) => clan.id === event.clanId)!,
    game: games.find((game) => game.id === event.gameId)!,
    attendees: eventAttendees
      .filter((attendee) => attendee.eventId === event.id)
      .map((attendee) => ({
        ...attendee,
        profile: profiles.find((profile) => profile.id === attendee.profileId)!,
      })),
  };
}

export async function listLfgPosts() {
  return lfgPosts.map((post) => ({
    ...post,
    profile: profiles.find((profile) => profile.id === post.profileId)!,
    game: games.find((game) => game.id === post.gameId)!,
  }));
}

export async function listProfiles() {
  return profiles;
}

export async function getProfileByNick(nick: string) {
  return profiles.find((profile) => profile.nick.toLowerCase() === nick.toLowerCase()) ?? null;
}

export async function getDashboardSnapshot(profileId: string) {
  const profile = profiles.find((entry) => entry.id === profileId)!;
  const memberships = clanMembers.filter((member) => member.profileId === profileId);
  const memberClanIds = memberships.map((membership) => membership.clanId);

  return {
    profile,
    memberships: memberships.map((membership) => ({
      ...membership,
      clan: clans.find((clan) => clan.id === membership.clanId)!,
    })),
    upcomingEvents: events.filter((event) => memberClanIds.includes(event.clanId)).slice(0, 3),
    reviews: reviews.filter((review) => review.targetProfileId === profileId),
    openRequests: clanJoinRequests.filter((request) => request.profileId === profileId),
  };
}

export async function getRecommendations(profileId: string) {
  const profile = profiles.find((entry) => entry.id === profileId)!;

  return clans
    .map((clan) => ({
      clan,
      result: calculateCompatibility(profile, clan),
    }))
    .sort((left, right) => right.result.score - left.result.score);
}

export async function listReports() {
  return reports.map((report) => ({
    ...report,
    reporter: profiles.find((profile) => profile.id === report.reporterProfileId)!,
  }));
}
