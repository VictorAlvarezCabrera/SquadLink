# SquadLink

SquadLink es una plataforma web multijuego para crear clanes, reclutar jugadores, organizar eventos y publicar anuncios LFG con una capa de compatibilidad transparente entre jugadores y clanes.

## Stack

- Next.js 16 con App Router
- TypeScript
- Tailwind CSS v4
- shadcn/ui
- Supabase Auth + PostgreSQL + RLS
- Zod
- Vitest

## Estado del proyecto

El repositorio queda listo para dos modos:

- `demo/local`: usa datos semilla embebidos y autenticación demo mediante cookie para defensa académica sin depender de servicios externos.
- `supabase`: usa autenticación real y la base de datos definida en `supabase/migrations`.

## Instalación

```bash
npm install
```

## Variables de entorno

Consulta `.env.example`.

## Desarrollo

```bash
npm run dev
```

Abre `http://localhost:3000`.

## Scripts

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

## Supabase

1. Crea un proyecto en Supabase.
2. Copia las variables a `.env.local`.
3. Aplica las migraciones de `supabase/migrations`.
4. Carga `supabase/seed/seed.sql`.
5. Cambia `NEXT_PUBLIC_APP_MODE=supabase`.

## Seeds demo

Incluyen usuarios y perfiles, catálogo base, clanes, miembros, solicitudes, eventos, publicaciones LFG y reportes.

## Estructura

```text
app/                Rutas App Router y server actions
components/         Layout y UI compartida
features/           Módulos de presentación por dominio
services/           Casos de uso y acceso a datos
lib/                Utilidades comunes, auth y Supabase
validations/        Esquemas Zod
types/              Tipos de dominio
data/               Datos demo para modo local
supabase/           SQL de migraciones y seed
tests/              Tests unitarios e integración base
docs/               Arquitectura, base de datos y roadmap
```

## Arquitectura y documentación

- [Arquitectura](./docs/architecture.md)
- [Base de datos](./docs/database.md)
- [Roadmap](./docs/roadmap.md)

## Demo login

En modo demo puedes entrar con cualquiera de estos usuarios y contraseña `demo12345`:

- `admin@squadlink.gg`
- `lyra@squadlink.gg`
- `marco@squadlink.gg`
- `ines@squadlink.gg`

## Limitaciones reales

- Sin variables de Supabase activas, las mutaciones persisten solo a nivel de interfaz demo.
- Las políticas RLS y migraciones están preparadas para ejecución en Supabase, pero no pueden validarse contra una instancia remota desde este entorno.
